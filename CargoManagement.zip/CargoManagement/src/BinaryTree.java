
public class BinaryTree {
	Node root;
	int size;
	
	public BinaryTree() {
		root=null;
		size=0;
	}
	
	public int getSize() {
		return size;
	}
	
	public Node getRoot() {
		return root;
	}
	 void insert(cargoInfo ci) { 
	       root = insert(root, ci); 
	    } 
	      
	    Node insert(Node root, cargoInfo ci) { 
	  
	        if (root == null) { 
	            root = new Node(ci); 
	            return root; 
	        } 
	        
	        if (ci.getItemId() < root.item.getItemId()) 
	            root.left = insert(root.left, ci); 
	        else if (ci.getItemId() > root.item.getItemId()) 
	            root.right = insert(root.right, ci); 
	  
	        return root; 
	    } 
	    void deleteKey(int key) 
	    { 
	        root = delete(root, key); 
	    } 
	  
	    Node delete(Node root, int key) 
	    { 
	   
	        if (root == null)  return root; 
	  
	       
	        if (key < root.item.getItemId()) 
	            root.left = delete(root.left, key); 
	        else if (key > root.item.getItemId()) 
	            root.right = delete(root.right, key); 
	  
	        else
	        { 
	            
	            if (root.left == null) 
	                return root.right; 
	            else if (root.right == null) 
	                return root.left; 
	  
	            
	            int min = minValue(root.right); 
	            
	            root.right = delete(root.right, min); 
	        } 	  
	        return root; 
	    } 
	    
	    int minValue(Node root) 
	    { 
	        int minv = root.item.getItemId(); 
	        while (root.left != null) 
	        { 
	            minv = root.left.item.getItemId(); 
	            root = root.left; 
	        } 
	        return minv; 
	    } 
	    
	    public Node search(Node root,String x) 
	    { 
	   
	        if (root==null || root.item.getItemId() == Integer.parseInt(x)) 
	            return root; 
	        
	        if ( root.item.getItemId() > Integer.parseInt(x)) 
	            return search(root.left, x); 
	      
	        return search(root.right, x); 
	    } 
	    
	 
}
