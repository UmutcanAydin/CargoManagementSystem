import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Frame;

import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class signin extends JFrame {

	private JPanel contentPane;
	private JTextField txtName;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signin frame = new signin();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public signin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblCargoManagementSystem = new JLabel("CARGO MANAGEMENT SYSTEM");
		lblCargoManagementSystem.setForeground(Color.RED);
		lblCargoManagementSystem.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCargoManagementSystem.setBounds(94, 10, 257, 68);
		panel.add(lblCargoManagementSystem);
		
		JLabel lblUserName = new JLabel("admin");
		lblUserName.setForeground(Color.WHITE);
		lblUserName.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblUserName.setBounds(337, 88, 79, 32);
		panel.add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPassword.setBounds(94, 119, 79, 32);
		panel.add(lblPassword);
		
		txtName = new JTextField();
		txtName.setFont(new Font("Tahoma", Font.PLAIN, 13));
		txtName.setText("admin");
		txtName.setBounds(183, 96, 137, 19);
		panel.add(txtName);
		txtName.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(183, 127, 137, 19);
		panel.add(txtPassword);
		
		JLabel label = new JLabel("User Name :");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label.setBounds(94, 88, 79, 32);
		panel.add(label);
		
		JLabel label_1 = new JLabel("12345");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_1.setBounds(337, 119, 79, 32);
		panel.add(label_1);
		
		Button btnLogin = new Button("Login");
		btnLogin.setForeground(Color.BLACK);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = txtName.getText();
				String pass = txtPassword.getText();
				
				if(name.equals("admin") && pass.equals("12345")) {
					main main = new main();
					main.setVisible(true);
					setVisible(false);
				}else
					JOptionPane.showMessageDialog(contentPane,"Invalid password or username.");
			}
		});
		btnLogin.setFont(new Font("Arial Black", Font.BOLD, 12));
		btnLogin.setBounds(183, 182, 67, 21);
		panel.add(btnLogin);
	}
}
