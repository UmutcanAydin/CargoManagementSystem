import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class cargoInfo extends JPanel {
	private int itemId;
	private static int idCounter = 1; 
	private String sName;
	private String sAddress;
	private String sPhone;
	private String rName;
	private String rAddress;
	private String rPhone;
	private double weight;
	private String fragile;
	private boolean isDeleted = false;
	
	public cargoInfo(String sendName,String sendAddress,String sendPhone,String reName,String reAddress,
			String rePhone,double weight,String frag, BinaryTree bt) {
		setBackground(Color.WHITE);
		
		JLabel lblSenderAddress = new JLabel("Sender Address:");
		lblSenderAddress.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblSenderAddress.setForeground(Color.BLACK);
		
		JLabel lblReceiverAddress = new JLabel("Receiver Address:");
		lblReceiverAddress.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblReceiverAddress.setForeground(Color.BLACK);
		
		JLabel rAddressLabel = new JLabel("1");
		rAddressLabel.setFont(new Font("Tahoma", Font.PLAIN, 9));
		rAddressLabel.setForeground(Color.BLACK);
		
		JLabel sAddressLabel = new JLabel("1");
		sAddressLabel.setFont(new Font("Tahoma", Font.PLAIN, 9));
		sAddressLabel.setForeground(Color.BLACK);
		
		JButton btnMoreInfo = new JButton("More Info");
		btnMoreInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				moreInfo mi = new moreInfo(getsName(),getsAddress(),getsPhone(),
						getrName(),getrAddress(),getrPhone(),getWeight(),
						      isFragile(),getItemId(),bt);
				mi.setVisible(true);
				if(mi.isDeleted()==true) {			
					setDeleted(true);
					setVisible(false);
				}
			}
		});
		btnMoreInfo.setFont(new Font("Tahoma", Font.PLAIN, 9));
		
		JLabel fragileImgLabel = new JLabel("");
		fragileImgLabel.setFont(new Font("Tahoma", Font.PLAIN, 8));
		
		JLabel idLabel = new JLabel("New label");
		idLabel.setFont(new Font("Tahoma", Font.PLAIN, 9));
		
		JLabel lblId = new JLabel("ID :");
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 9));
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 9));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"2 days to delivery", "1 day to delivery", "In delivery", "Delivered"}));
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(28)
							.addComponent(fragileImgLabel, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(37)
							.addComponent(lblId)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(idLabel, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)))
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(14)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.RELATED, 264, Short.MAX_VALUE)
									.addComponent(btnMoreInfo, GroupLayout.PREFERRED_SIZE, 85, GroupLayout.PREFERRED_SIZE)
									.addContainerGap())
								.addGroup(groupLayout.createSequentialGroup()
									.addGap(18)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(lblSenderAddress, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 92, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblReceiverAddress, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 92, GroupLayout.PREFERRED_SIZE))
									.addPreferredGap(ComponentPlacement.RELATED)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(rAddressLabel, GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
										.addGroup(groupLayout.createSequentialGroup()
											.addComponent(sAddressLabel, GroupLayout.PREFERRED_SIZE, 176, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.RELATED)))
									.addGap(85))))
						.addGroup(groupLayout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(sAddressLabel)
								.addComponent(lblSenderAddress))
							.addGap(27)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(rAddressLabel)
								.addComponent(lblReceiverAddress)))
						.addComponent(fragileImgLabel, GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(btnMoreInfo)
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblId)
							.addComponent(idLabel)))
					.addContainerGap())
		);
		itemId = idCounter++;
		sName = sendName;
		sAddress = sendAddress;
		sPhone = sendPhone;
		rName = reName;
		rAddress = reAddress;
		rPhone = rePhone;
		this.weight = weight;
		fragile = frag;
		if(frag == "Yes") {
			Image fragileImg = new ImageIcon(getClass().getResource("/fragileImg.png")).getImage();
			fragileImgLabel.setIcon(new ImageIcon(fragileImg));
		}else {
			Image notfragileImg = new ImageIcon(getClass().getResource("/notfragileImg.png")).getImage();
			fragileImgLabel.setIcon(new ImageIcon(notfragileImg));
		}
		
		sAddressLabel.setText(sendAddress);
		rAddressLabel.setText(reAddress);
		idLabel.setText(Integer.toString(getItemId()));
		setLayout(groupLayout);
		
	}
	
	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	public String getsAddress() {
		return sAddress;
	}

	public void setsAddress(String sAddress) {
		this.sAddress = sAddress;
	}
	
	public String getsPhone() {
		return sPhone;
	}
	
	public void setsPhone(String sPhone) {
		this.sPhone = sPhone;
	}

	public String getrName() {
		return rName;
	}

	public void setrName(String rName) {
		this.rName = rName;
	}

	public String getrAddress() {
		return rAddress;
	}

	public void setrAddress(String rAddress) {
		this.rAddress = rAddress;
	}
	
	public String getrPhone() {
		return rPhone;
	}
	
	public void setrPhone(String rPhone) {
		this.rPhone = rPhone;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String isFragile() {
		return fragile;
	}

	public void setFragile(String fragile) {
		this.fragile = fragile;
	}
	
	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	
	public boolean getDeleted() {
		return isDeleted;
	}
	
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
}
