import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JTabbedPane;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingUtilities;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import javax.swing.JScrollPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class main extends JFrame {
 
	private JPanel contentPane;
	private JTextField searchTextField;
	private JTextField txtSenderName;
	private JTextField txtSenderAddress;
	private JTextField txtReceiverName;
	private JTextField txtReceiverAddress;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField txtReceiverPhone;
	private JTextField txtSenderPhone;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
					frame.setResizable(false);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public main() {
		BinaryTree bt = new BinaryTree();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 531, 527);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane, BorderLayout.CENTER);
		
		JPanel tabManagement = new JPanel();
		JScrollPane scroll = new JScrollPane(tabManagement,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		tabManagement.setBackground(Color.DARK_GRAY);
		tabManagement.setToolTipText("");
		tabbedPane.addTab("Management", null, scroll, null);
		searchTextField = new JTextField();
		searchTextField.setColumns(20);
		
		JButton btnSearch = new JButton("");
	
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 10));
		Image img = new ImageIcon(getClass().getResource("/iconSearch.png")).getImage();
		btnSearch.setIcon(new ImageIcon(img));
		btnSearch.setPreferredSize(new Dimension(22,22));
		tabManagement.setLayout(new WrapLayout());
		tabManagement.add(searchTextField);
		tabManagement.add(btnSearch);
		
		JLabel lblShowAll = new JLabel("Show All");
		lblShowAll.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Component comps[] = tabManagement.getComponents();
				for(int i = 3;i<comps.length;i++) {
					if(((cargoInfo) comps[i]).getDeleted()==false) {
						comps[i].setVisible(true);
					}
				}
			}
		});
		lblShowAll.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblShowAll.setForeground(Color.WHITE);
		tabManagement.add(lblShowAll);
		
		JPanel tabOrder = new JPanel();
		tabOrder.setBackground(Color.DARK_GRAY);
		tabbedPane.addTab("Order", null, tabOrder, null);
	
		JLabel lblSenderAddress = new JLabel("Sender Name :");
		lblSenderAddress.setForeground(Color.WHITE);
		lblSenderAddress.setBounds(106, 27, 102, 41);
		lblSenderAddress.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JLabel lblReceiverName = new JLabel(" Receiver Name :");
		lblReceiverName.setForeground(Color.WHITE);
		lblReceiverName.setBounds(92, 168, 116, 41);
		lblReceiverName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JLabel lblReceiverAddress = new JLabel(" Receiver Address :");
		lblReceiverAddress.setForeground(Color.WHITE);
		lblReceiverAddress.setBounds(77, 215, 130, 41);
		lblReceiverAddress.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JLabel lblWeight = new JLabel("Weight(kg) :");
		lblWeight.setForeground(Color.WHITE);
		lblWeight.setBounds(122, 295, 87, 41);
		lblWeight.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JLabel lblFragility = new JLabel(" Fragile :");
		lblFragility.setForeground(Color.WHITE);
		lblFragility.setBounds(147, 339, 61, 41);
		lblFragility.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JLabel label = new JLabel("Sender Address :");
		label.setForeground(Color.WHITE);
		label.setBounds(92, 78, 116, 41);
		label.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		txtSenderName = new JTextField();
		txtSenderName.setBounds(226, 40, 157, 19);
		txtSenderName.setColumns(10);
		
		txtSenderAddress = new JTextField();
		txtSenderAddress.setBounds(226, 91, 157, 19);
		txtSenderAddress.setColumns(10);
		
		txtReceiverName = new JTextField();
		txtReceiverName.setBounds(226, 181, 157, 19);
		txtReceiverName.setColumns(10);
		
		txtReceiverAddress = new JTextField();
		txtReceiverAddress.setBounds(225, 228, 157, 19);
		txtReceiverAddress.setColumns(10);
		
		JFormattedTextField txtWeight = new JFormattedTextField();
		txtWeight.setBounds(226, 308, 157, 19);
		txtWeight.getDocument().addDocumentListener(new DocumentListener() {
			
		
			@Override
			public void insertUpdate(DocumentEvent e) {
				Runnable format = new Runnable() {
					
					@Override
					public void run() {
						String txt = txtWeight.getText();
						if(!txt.matches("\\d*(\\.\\d{0,2})?")) {
							txtWeight.setText(txt.substring(0,txt.length()-1));
						}
						
					}
				};
				SwingUtilities.invokeLater(format);
			}
			@Override
			public void removeUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			
			@Override
			public void changedUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		JRadioButton rdbtnYes = new JRadioButton("Yes");
		rdbtnYes.setBounds(223, 351, 49, 21);
		rdbtnYes.setSelected(true);
		buttonGroup.add(rdbtnYes);
		
		JRadioButton rdbtnNo = new JRadioButton("No");
		rdbtnNo.setBounds(299, 351, 49, 21);
		buttonGroup.add(rdbtnNo);
		
		JButton btnOrder = new JButton("Order");
		btnOrder.setBounds(212, 398, 85, 33);
		btnOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				String selected = "";
				Enumeration<AbstractButton> en = buttonGroup.getElements();
				while(en.hasMoreElements()) {
					    JRadioButton rb = (JRadioButton) en.nextElement();				
					    if(rb.isSelected())				
				        selected = rb.getText();
					}
				cargoInfo ci = new cargoInfo(txtSenderName.getText(),txtSenderAddress.getText(),
						txtSenderPhone.getText(),
						txtReceiverName.getText(),
						txtReceiverAddress.getText(),
						txtReceiverPhone.getText(),
						Double.parseDouble(txtWeight.getText()),
						selected,
						bt);
				bt.insert(ci);
				txtSenderName.setText("");
				txtSenderAddress.setText("");
				txtSenderPhone.setText("");
				txtReceiverName.setText("");
				txtReceiverAddress.setText("");
				txtReceiverPhone.setText("");
				txtWeight.setText("");
				buttonGroup.clearSelection();
				rdbtnYes.setSelected(true);
							
				tabManagement.add(ci);
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Please fill all information");
				}
				
			}
		});
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean success = true;
				try {
				Node contain = bt.search(bt.root, searchTextField.getText());

				if(contain != null) {
					Component comps[] = tabManagement.getComponents();
					for(int i = 3;i<comps.length;i++) {
						comps[i].setVisible(false);
					}
						comps[Integer.parseInt(searchTextField.getText())+2].setVisible(true);
					
					
				}
				else if(contain == null)
					JOptionPane.showMessageDialog(null, "Item doesn't exist");
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Please enter an id");
				}
			}
		});
		btnOrder.setBackground(Color.WHITE);
		btnOrder.setFont(new Font("Tahoma", Font.PLAIN, 15));
		tabOrder.setLayout(null);
		tabOrder.add(lblSenderAddress);
		tabOrder.add(txtSenderName);
		tabOrder.add(label);
		tabOrder.add(txtSenderAddress);
		tabOrder.add(lblReceiverName);
		tabOrder.add(txtReceiverName);
		tabOrder.add(lblReceiverAddress);
		tabOrder.add(txtReceiverAddress);
		tabOrder.add(lblWeight);
		tabOrder.add(txtWeight);
		tabOrder.add(lblFragility);
		tabOrder.add(rdbtnYes);
		tabOrder.add(rdbtnNo);
		tabOrder.add(btnOrder);
		
		JLabel lblReceiverPhone = new JLabel(" Receiver Phone :");
		lblReceiverPhone.setForeground(Color.WHITE);
		lblReceiverPhone.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblReceiverPhone.setBounds(92, 253, 130, 41);
		tabOrder.add(lblReceiverPhone);
		
		txtReceiverPhone = new JTextField();
		txtReceiverPhone.setColumns(10);
		txtReceiverPhone.setBounds(226, 266, 157, 19);
		tabOrder.add(txtReceiverPhone);
		
		JLabel lblSenderPhone = new JLabel("Sender Phone :");
		lblSenderPhone.setForeground(Color.WHITE);
		lblSenderPhone.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblSenderPhone.setBounds(106, 122, 116, 41);
		tabOrder.add(lblSenderPhone);
		
		txtSenderPhone = new JTextField();
		txtSenderPhone.setColumns(10);
		txtSenderPhone.setBounds(226, 135, 157, 19);
		tabOrder.add(txtSenderPhone);
		
	}
}
