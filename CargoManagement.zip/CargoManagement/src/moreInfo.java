import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import java.awt.Color;
import java.awt.Dialog.ModalityType;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Window.Type;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class moreInfo extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JButton okButton;
	private boolean isDeleted = false;
	
	public moreInfo(String sendName,String sendAddress,String sendPhone,String reName,String reAddress,
			String rePhone,double weight,String frag,int ID, BinaryTree bt) {
		setType(Type.POPUP);
		setResizable(false);
		setModal(true);
		setModalityType(ModalityType.APPLICATION_MODAL);
		setBounds(100, 100, 545, 523);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(Color.WHITE);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel bigFragileImgLabel = new JLabel("New label");
		bigFragileImgLabel.setBounds(202, 10, 130, 130);
		contentPanel.add(bigFragileImgLabel);
		{
			JLabel lblNewLabel = new JLabel("Sender Name: ");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblNewLabel.setBounds(10, 241, 90, 13);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblReceiverAddress = new JLabel("Sender Address: ");
			lblReceiverAddress.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblReceiverAddress.setBounds(10, 271, 94, 13);
			contentPanel.add(lblReceiverAddress);
		}
		{
			JLabel senderNameLabel = new JLabel("1");
			senderNameLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
			senderNameLabel.setBounds(122, 241, 210, 13);
			contentPanel.add(senderNameLabel);
			senderNameLabel.setText(sendName);
		}
		{
			JLabel senderAddLabel = new JLabel("2");
			senderAddLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
			senderAddLabel.setBounds(122, 271, 354, 13);
			contentPanel.add(senderAddLabel);
			senderAddLabel.setText(sendAddress);
		}
		{
			JLabel lblID = new JLabel("ID:");
			lblID.setFont(new Font("Tahoma", Font.BOLD, 12));
			lblID.setBounds(241, 150, 29, 13);
			contentPanel.add(lblID);
		}
		{
			JLabel lblrec = new JLabel("Receiver Name:");
			lblrec.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblrec.setBounds(10, 360, 90, 13);
			contentPanel.add(lblrec);
		}
		{
			JLabel lblReceiverAddress_1 = new JLabel("Receiver Address:");
			lblReceiverAddress_1.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblReceiverAddress_1.setBounds(10, 392, 102, 13);
			contentPanel.add(lblReceiverAddress_1);
		}
		{
			JLabel recNameLabel = new JLabel("3");
			recNameLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
			recNameLabel.setBounds(122, 360, 210, 13);
			contentPanel.add(recNameLabel);
			recNameLabel.setText(reName);
		}
		{
			JLabel recAddLabel = new JLabel("4");
			recAddLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
			recAddLabel.setBounds(122, 392, 354, 13);
			contentPanel.add(recAddLabel);
			recAddLabel.setText(reAddress);
		}
		{
			JLabel lblweight = new JLabel("Weight:");
			lblweight.setFont(new Font("Tahoma", Font.BOLD, 12));
			lblweight.setBounds(223, 173, 53, 14);
			contentPanel.add(lblweight);
		}
		{
			JLabel idLabel = new JLabel("3");
			idLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
			idLabel.setBounds(280, 150, 110, 13);
			contentPanel.add(idLabel);
			idLabel.setText(Integer.toString(ID));
		}
		{
			JLabel weightLabel = new JLabel("3");
			weightLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
			weightLabel.setBounds(281, 174, 43, 13);
			contentPanel.add(weightLabel);
			weightLabel.setText(Double.toString(weight));
		}
		{
			JLabel lblKg = new JLabel("KG");
			lblKg.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblKg.setBounds(330, 174, 29, 13);
			contentPanel.add(lblKg);
		}
		{
			JLabel lblSenderPhone = new JLabel("Sender Phone: ");
			lblSenderPhone.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblSenderPhone.setBounds(10, 300, 94, 13);
			contentPanel.add(lblSenderPhone);
		}
		{
			JLabel lblReceiverPhone = new JLabel("Receiver Phone:");
			lblReceiverPhone.setFont(new Font("Tahoma", Font.BOLD, 11));
			lblReceiverPhone.setBounds(10, 415, 102, 13);
			contentPanel.add(lblReceiverPhone);
		}
		{
			JLabel senderPhoneLabel = new JLabel("1");
			senderPhoneLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
			senderPhoneLabel.setBounds(122, 300, 268, 13);
			contentPanel.add(senderPhoneLabel);
			senderPhoneLabel.setText(sendPhone);
		}
		{
			JLabel receiverPhoneLabel = new JLabel("1");
			receiverPhoneLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
			receiverPhoneLabel.setBounds(122, 415, 268, 13);
			contentPanel.add(receiverPhoneLabel);
			receiverPhoneLabel.setText(rePhone);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(Color.WHITE);
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("Delete");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int dialogButton = JOptionPane.YES_NO_OPTION;
						int dialogResult = JOptionPane.showConfirmDialog 
								(null, "Are you sure you want to delete this order?","Warning",dialogButton);
						if(dialogResult == JOptionPane.YES_OPTION){
							bt.deleteKey(ID);
							setVisible(false);
							setDeleted(true);
							
						}
					}
				});
				okButton.setForeground(Color.BLACK);
				okButton.setBackground(Color.WHITE);
				okButton.setActionCommand("OK");
				getRootPane().setDefaultButton(okButton);
			}
			GroupLayout gl_buttonPane = new GroupLayout(buttonPane);
			gl_buttonPane.setHorizontalGroup(
				gl_buttonPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_buttonPane.createSequentialGroup()
						.addContainerGap()
						.addComponent(okButton)
						.addContainerGap(363, Short.MAX_VALUE))
			);
			gl_buttonPane.setVerticalGroup(
				gl_buttonPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_buttonPane.createSequentialGroup()
						.addComponent(okButton, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
			);
			if(frag == "Yes") {
				Image fragileImg = new ImageIcon(getClass().getResource("/biggerFragile.png")).getImage();
				bigFragileImgLabel.setIcon(new ImageIcon(fragileImg));
			}else {
				Image notfragileImg = new ImageIcon(getClass().getResource("/biggerNotFragile.png")).getImage();
				bigFragileImgLabel.setIcon(new ImageIcon(notfragileImg));
			}
			
			buttonPane.setLayout(gl_buttonPane);
		}
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
}
