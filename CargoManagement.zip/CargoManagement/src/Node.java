
public class Node {
	cargoInfo item;
	Node left,right;
	
	public Node(cargoInfo newItem) {
		item = newItem;
		left = right = null;
	}
}
